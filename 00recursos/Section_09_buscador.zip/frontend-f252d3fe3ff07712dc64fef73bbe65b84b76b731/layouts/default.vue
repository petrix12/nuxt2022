<template>
  <v-app>
    <v-navigation-drawer 
    app
    v-model="drawer"
    :clipped="$vuetify.breakpoint.lgAndUp"
    color="grey lighten-4"
    >
     <v-list color="primary--text">
       <v-list-item to="/">
         <v-list-item-icon>
          <v-icon>mdi-home</v-icon>
        </v-list-item-icon>
        <v-list-item-content>
          <v-list-item-title>
            Inicio
          </v-list-item-title>
        </v-list-item-content>
       </v-list-item>
       <v-list-item
        v-for="link in links"
        :key="link.id"
        :to="{name:'category', params:{category:link.slug}}"
       >
        <v-list-item-icon>
          <v-icon>{{link.icon}}</v-icon>
        </v-list-item-icon>
        <v-list-item-content>
          <v-list-item-title>
            {{link.name}}
          </v-list-item-title>
        </v-list-item-content>
       </v-list-item>
     </v-list>
    </v-navigation-drawer>

    <v-app-bar app :clipped-left="$vuetify.breakpoint.lgAndUp"  color="grey lighten-4" flat>
      <v-app-bar-nav-icon @click="drawer = !drawer"></v-app-bar-nav-icon>
      <v-toolbar-title v-text="title"></v-toolbar-title>
      <v-spacer></v-spacer>
      <v-menu v-model="search" :close-on-content-click="false" offset-y>
        <template v-slot:activator="{on}">
          <v-btn v-on="on" color="primary" icon>
            <v-icon>mdi-magnify</v-icon>
          </v-btn>
        </template>
        <v-card>
          <v-card-title>Buscar receta</v-card-title>
          <v-card-text>
            <v-text-field outlined 
            label="Nombre receta" 
            dense v-model="findRecipe"
            @input="searchRecipe()"
            ></v-text-field>
            <v-list v-if="findRecipe.length != 0">
              <v-list-item v-for="recipe in recipes" :key="recipe.id" 
              @click="seeRecipe(recipe.category.slug, recipe.id)">
                {{recipe.name}}
              </v-list-item>
            </v-list>
           
          </v-card-text>
        </v-card>

      </v-menu>
    </v-app-bar>
    

    <v-main class="grey lighten-4">
      <nuxt/>
    </v-main>

    <v-footer padless>
      <v-row justify="center" no-gutters>
        <v-btn color="primary" small icon> <v-icon>mdi-facebook</v-icon> </v-btn>
        <v-btn color="primary" small icon> <v-icon>mdi-instagram</v-icon> </v-btn>
        <v-btn color="primary" small icon> <v-icon>mdi-pinterest</v-icon> </v-btn>
        <v-btn color="primary" small icon> <v-icon>mdi-twitter</v-icon> </v-btn>
        <v-col class="text-center primary--text" cols="12">
          &copy; {{new Date().getFullYear()}} - LE COQ
        </v-col>
      </v-row>
    </v-footer>
  </v-app>
</template>

<script>
import {mapGetters} from 'vuex'

export default {
  data () {
    return {
      drawer:false,
      title:"LEC COQ",
      search:false,
      findRecipe:""
    }
  },
  computed:{
    ...mapGetters({
      links:"readCategories",
      recipes:"readLoadedRecipes"
    }),
    filteredRecipe(){
      return this.recipes.filter(recipe => 
       recipe.name.toLowerCase().match(this.findRecipe.toLowerCase())
      )
    }
  },
  methods:{
    seeRecipe(category, recipe){
      this.findRecipe = ""
      this.search = false
      this.$router.push({name:'category-recipe', params:{category, recipe}})
    },
    searchRecipe(){
      this.$store.dispatch("searchRecipe", this.findRecipe)
    }
  }
}
</script>
