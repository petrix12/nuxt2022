<template>
    <div>
        <h1>Lista de {{$route.params.products}}</h1>
        <ul>
            <li>item</li>
            <li>item</li>
            <li>item</li>
            <li>item</li>
            <li>item</li>
        </ul>
    </div>
</template>