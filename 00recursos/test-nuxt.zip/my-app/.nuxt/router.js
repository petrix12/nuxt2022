import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _0d3ce2b6 = () => interopDefault(import('..\\pages\\contact.vue' /* webpackChunkName: "pages/contact" */))
const _bf6fffc4 = () => interopDefault(import('..\\pages\\users.vue' /* webpackChunkName: "pages/users" */))
const _6ef2f8b8 = () => interopDefault(import('..\\pages\\users\\one.vue' /* webpackChunkName: "pages/users/one" */))
const _17f8f20c = () => interopDefault(import('..\\pages\\users\\_id.vue' /* webpackChunkName: "pages/users/_id" */))
const _5ade25e8 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _0c7b3e09 = () => interopDefault(import('..\\pages\\_products\\index.vue' /* webpackChunkName: "pages/_products/index" */))
const _00f74e92 = () => interopDefault(import('..\\pages\\_products\\list.vue' /* webpackChunkName: "pages/_products/list" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/contact",
    component: _0d3ce2b6,
    name: "contact"
  }, {
    path: "/users",
    component: _bf6fffc4,
    name: "users",
    children: [{
      path: "one",
      component: _6ef2f8b8,
      name: "users-one"
    }, {
      path: ":id?",
      component: _17f8f20c,
      name: "users-id"
    }]
  }, {
    path: "/",
    component: _5ade25e8,
    name: "index"
  }, {
    path: "/:products",
    component: _0c7b3e09,
    name: "products"
  }, {
    path: "/:products/list",
    component: _00f74e92,
    name: "products-list"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config.app && config.app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
