<template>
  <v-container>
   
   <v-btn class="primary">primary</v-btn>
   <v-btn class="secondary">secondary</v-btn>
   <v-btn class="accent">accent</v-btn>


  <div class="mt-2">
     <v-btn class="warning">warning</v-btn>
     <v-btn class="error">error</v-btn>
     <v-btn class="success">success</v-btn>
     <v-btn class="info">info</v-btn>
  </div>

  </v-container>
</template>

<script>
export default {

}
</script>
