import styled from 'styled-components';
import { Flex } from '@buffetjs/core';

const PermissionWrapper = styled(Flex)`
  flex: 1;
`;

export default PermissionWrapper;
