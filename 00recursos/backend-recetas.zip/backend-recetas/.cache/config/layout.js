'use strict';

module.exports = {
  administrator: {
    actions: {
      create: 'Admin.create',
      update: 'Admin.update',
    },
  },
};
