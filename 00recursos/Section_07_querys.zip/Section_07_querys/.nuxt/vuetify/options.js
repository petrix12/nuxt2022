export default {"theme":{"dark":false,"themes":{"light":{"primary":"#8A9337","accent":"#EFF4C3","secondary":"#3D405B","info":"#26a69a","warning":"#ffc107","error":"#dd2c00","success":"#00e676"}}}}
